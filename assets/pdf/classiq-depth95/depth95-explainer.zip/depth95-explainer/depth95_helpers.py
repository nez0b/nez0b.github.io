"""Helpers for classiq-challenge-depth-95-explainer.ipynb.

Author: PoJen Wang (pwang529@gmail.com)

Everything the notebook needs besides numpy and matplotlib lives here, so the notebook runs from this folder
with no other files than data/:

  * the challenge's logo (logo_pixel, target_mask, BASELINE), as the host's baseline notebook defines it;
  * a small OpenQASM 2 reader for u3/cx circuits and the challenge's depth count (parse_qasm, asap_depth);
  * save_figure: a quality check (no text off the canvas, no overlapping labels) before a figure is written;
  * run_guarded: runs a program with a memory limit, and refuses to start it while the machine is short of RAM.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from pathlib import Path

import numpy as np

# ---------------------------------------------------------------------------------------------------------------
# The challenge
# ---------------------------------------------------------------------------------------------------------------
GRID_SIZE = 64
BASELINE = {"width": 18, "depth": 5329, "cx": 3502}    # the organisers' baseline circuit


def logo_pixel(x: int, y: int) -> bool:
    """True exactly on a black pixel (x, y) of the Classiq logo: a square, a bar and two discs."""
    return ((2 <= x <= 26 and 29 <= y <= 53)
            or (26 <= x <= 49 and 39 <= y <= 43)
            or (x - 55) ** 2 + (y - 41) ** 2 <= 42
            or (x - 40) ** 2 + (y - 19) ** 2 <= 72)


def target_mask() -> np.ndarray:
    """(64, 64) bool array indexed as mask[y, x]."""
    return np.array([[logo_pixel(x, y) for x in range(GRID_SIZE)] for y in range(GRID_SIZE)])


# ---------------------------------------------------------------------------------------------------------------
# Circuits
# ---------------------------------------------------------------------------------------------------------------
def parse_qasm(path):
    """Gate list of a u3/cx OpenQASM 2 file as [(name, [qubits]), ...]."""
    ops = []
    for line in Path(path).read_text().splitlines():
        m = re.match(r"^\s*(cx|u3)(\([^)]*\))?\s+(.*);\s*$", line)
        if m:
            ops.append((m.group(1), [int(w) for w in re.findall(r"q\[(\d+)\]", m.group(3))]))
    return ops


def asap_depth(ops, n_wires: int = 18) -> int:
    """Depth as the challenge counts it: every gate takes one layer, and gates on different qubits share one."""
    ready = [0] * n_wires
    for _, ws in ops:
        t = max(ready[w] for w in ws) + 1
        for w in ws:
            ready[w] = t
    return max(ready)


# ---------------------------------------------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------------------------------------------
def save_figure(fig, name: str, outdir, pdf: bool = True) -> None:
    """Check a figure, then save it as outdir/name.png (and .pdf).

    The check fails if any visible text leaves the canvas, or if two labels drawn with gid='ann' overlap.
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    fb = fig.bbox
    texts = list(fig.texts)
    for ax in fig.axes:
        texts += [ax.title, ax.xaxis.label, ax.yaxis.label] + list(ax.texts)
        for axis, lim in ((ax.xaxis, sorted(ax.get_xlim())), (ax.yaxis, sorted(ax.get_ylim()))):
            for loc, lab in zip(axis.get_majorticklocs(), axis.get_ticklabels()):
                if lim[0] <= loc <= lim[1]:
                    texts.append(lab)
        if ax.get_legend():
            texts += list(ax.get_legend().get_texts())
    texts = [t for t in texts if t.get_visible() and t.get_text().strip()]
    problems = []
    for t in texts:
        bb = t.get_window_extent(r)
        if bb.x0 < fb.x0 - 1 or bb.y0 < fb.y0 - 1 or bb.x1 > fb.x1 + 1 or bb.y1 > fb.y1 + 1:
            problems.append(f"text outside the canvas: {t.get_text()!r}")
    ann = [t for t in texts if t.get_gid() == "ann"]
    for i in range(len(ann)):
        for j in range(i + 1, len(ann)):
            if ann[i].get_window_extent(r).overlaps(ann[j].get_window_extent(r)):
                problems.append(f"labels overlap: {ann[i].get_text()!r} / {ann[j].get_text()!r}")
    if problems:
        raise AssertionError("figure QC failed: " + "; ".join(problems))
    fig.savefig(outdir / f"{name}.png", dpi=150)
    if pdf:
        fig.savefig(outdir / f"{name}.pdf")
    print(f"figure {name}: {len(texts)} text items checked, saved")


# ---------------------------------------------------------------------------------------------------------------
# Running a program with a memory guard
# ---------------------------------------------------------------------------------------------------------------
def free_memory_percent():
    """Available RAM in percent, or None where it cannot be measured."""
    try:
        import psutil  # optional
        vm = psutil.virtual_memory()
        return 100.0 * vm.available / vm.total
    except Exception:
        pass
    try:
        info = {}
        with open("/proc/meminfo") as fh:
            for line in fh:
                k, v = line.split(":", 1)
                info[k] = int(v.split()[0])
        return 100.0 * info["MemAvailable"] / info["MemTotal"]
    except Exception:
        pass
    try:  # macOS
        out = subprocess.run(["memory_pressure", "-Q"], capture_output=True, text=True, timeout=10).stdout
        m = re.search(r"free percentage:\s*(\d+)%", out)
        return float(m.group(1)) if m else None
    except Exception:
        return None


def _rss_gib(pid: int):
    try:
        out = subprocess.run(["ps", "-o", "rss=", "-p", str(pid)], capture_output=True, text=True, timeout=5).stdout
        return int(out.strip()) / 1048576 if out.strip() else None
    except Exception:
        return None


def run_guarded(cmd, stdout_path, stderr_path, max_gb: float = 4.0, min_free: float = 20.0,
                timeout: float = 600.0, tries: int = 6, wait: float = 10.0) -> float:
    """Run cmd with its output in two files. Refuse to start while less than min_free % of RAM is available
    (retrying a few times), and kill the program if it grows past max_gb. Returns the program's own run time in
    seconds (time spent waiting for memory is not included)."""
    cmd = [str(c) for c in cmd]
    for attempt in range(tries):
        free = free_memory_percent()
        if free is None or free >= min_free:
            break
        print(f"[memory guard] only {free:.1f}% of RAM available (< {min_free:.0f}%), waiting {wait:.0f} s")
        time.sleep(wait)
    else:
        raise RuntimeError(f"[memory guard] refused to start: less than {min_free:.0f}% of RAM available")
    with open(stdout_path, "w") as fo, open(stderr_path, "w") as fe:
        proc = subprocess.Popen(cmd, stdout=fo, stderr=fe)
        t0 = time.time()
        while proc.poll() is None:
            rss = _rss_gib(proc.pid)
            if rss is not None and rss > max_gb:
                proc.kill()
                proc.wait()
                raise RuntimeError(f"[memory guard] killed: {rss:.2f} GiB is over the {max_gb} GiB limit")
            if time.time() - t0 > timeout:
                proc.kill()
                proc.wait()
                raise RuntimeError(f"[memory guard] killed after the {timeout:.0f} s time limit")
            time.sleep(0.2)
    elapsed = time.time() - t0
    if proc.returncode != 0:
        raise RuntimeError(f"{Path(cmd[0]).name} exited with code {proc.returncode}; see {stderr_path}")
    return elapsed
