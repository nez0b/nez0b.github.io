/* colsa: simulated-annealing search for a shallow column code.
 *
 * State: a gate list on 10 wires (0..5 = x0..x5 = q0..q5, 6..9 = helpers q14..q17 starting at 0) and a placement
 * of the six column outputs (R0 R1 R2 R3 fam L) on distinct wires with a polarity.  Gates: not, cx, ccx, c3x with
 * signed controls.  A column x (0..63) is right when its output word is in the contract's allowed set.
 * Evaluation is bit-parallel over the 64 columns (one uint64 per wire).
 * Depth estimate: ASAP schedule, cx 1, ccx 7, c3x 13 (a reader blocks later writers of its controls until it ends).
 * Energy = WV * wrong_columns + WC * max(0, est - cap) + 0.01 * est + 0.001 * gates.
 * Pool mode: environment POOL_SLACK (see the globals) also prints distinct near-best right states.
 * Every time a state with 0 wrong columns and est <= cap appears, it is printed and cap drops by one.
 *
 * Usage: colsa TABLE INIT|- SEED ITERS CAP0 [WV WC T0 T1 NMAX RESTARTS]
 *   TABLE: 64 lines, hex mask of allowed 6-bit words (bit0 R0 .. bit5 L) per column.
 *   INIT : "place w0 p0 ... w5 p5" line then gate lines "type t c0 p0 c1 p1 c2 p2" (type 0 not,1 cx,2 ccx,3 c3x;
 *          wires in 0..9), or '-' for a random start.
 * Output lines: "SOL est=E gates=N wrong=0 iter=I" followed by "PLACE ..." and "GATES ..." (same format as INIT).
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>

#ifndef NW
#define NW 10                 /* -DNW=11: one more helper (wire 10 = q12, lent by a 7-wire row code, 2026-09-23) */
#endif
#define NMAXG 96
typedef struct { int type, t, c[3], p[3]; } Gate;
typedef struct { int n; Gate g[NMAXG]; int pw[6], pp[6]; } State;

static uint64_t ALLOWED[64];      /* per column: mask over words */
static uint64_t COLS_OF_WORD[64]; /* per word: mask over columns that allow it */
static uint64_t XINIT[6];
/* env CLEAN_WIRE=w (2026-09-23): wire w must end at 0 on every column and hold no output, so the middle can use it as
 * a clean wire (used by an experimental middle that needs one more clean helper).  A column where it ends at 1
 * is wrong. */
static int CLEAN_W = -1;
static int NMAX = 64;
static double WV = 20, WC = 3, TT0 = 3, TT1 = 0.05;
/* pool mode (env POOL_SLACK >= 0): also print distinct right states with est <= best est + POOL_SLACK and at most
 * POOL_NSLACK more gates than the best and est <= POOL_ABSMAX, at least POOL_GAP iterations apart, at most POOL_MAX
 * per run. */
static int POOL_SLACK = -1, POOL_NSLACK = 3, POOL_MAX = 400, POOL_ABSMAX = 1 << 30; static long POOL_GAP = 100000;
#define HSIZE (1 << 20)
static uint64_t *HSET;
static uint64_t state_hash(const State *s) {
    uint64_t h = 1469598103934665603ULL;
#define MIX(v) do { h ^= (uint64_t)(v) + 0x9E3779B97F4A7C15ULL; h *= 1099511628211ULL; } while (0)
    for (unsigned r = 0; r < sizeof s->pw / sizeof s->pw[0]; r++) { MIX(s->pw[r]); MIX(s->pp[r]); }
    MIX(s->n);
    for (int k = 0; k < s->n; k++) { const Gate *g = &s->g[k]; MIX(g->type); MIX(g->t);
        for (int j = 0; j < 3; j++) { MIX(g->c[j]); MIX(g->p[j]); } }
    return h | 1;
}
static int seen_before(uint64_t h) {           /* insert; 1 if it was there */
    uint64_t i = h & (HSIZE - 1);
    while (HSET[i]) { if (HSET[i] == h) return 1; i = (i + 1) & (HSIZE - 1); }
    HSET[i] = h; return 0;
}

static uint64_t rng_s[2];
static inline uint64_t rotl(const uint64_t x, int k) { return (x << k) | (x >> (64 - k)); }
static uint64_t rnd(void) { uint64_t s0 = rng_s[0], s1 = rng_s[1], r = s0 + s1; s1 ^= s0; rng_s[0] = rotl(s0, 55) ^ s1 ^ (s1 << 14); rng_s[1] = rotl(s1, 36); return r; }
static int rint_(int n) { return (int)(rnd() % (uint64_t)n); }
static double runif(void) { return (rnd() >> 11) * (1.0 / 9007199254740992.0); }

static int ncontrols(int type) { return type == 0 ? 0 : type; }
static int dur(int type) { return type == 0 ? 0 : type == 1 ? 1 : type == 2 ? 7 : 13; }

static int wrong_columns(const State *s) {
    uint64_t v[NW];
    for (int i = 0; i < 6; i++) v[i] = XINIT[i];
    for (int i = 6; i < NW; i++) v[i] = 0;
    for (int k = 0; k < s->n; k++) {
        const Gate *g = &s->g[k];
        uint64_t m = ~0ULL;
        for (int j = 0; j < ncontrols(g->type); j++) m &= g->p[j] ? ~v[g->c[j]] : v[g->c[j]];
        v[g->t] ^= m;
    }
    uint64_t out[6];
    for (int r = 0; r < 6; r++) out[r] = s->pp[r] ? ~v[s->pw[r]] : v[s->pw[r]];
    if (CLEAN_W >= 0) for (int r = 0; r < 6; r++) if (s->pw[r] == CLEAN_W) return 64;
    uint64_t ok = 0;
    for (int w = 0; w < 64; w++) {
        if (!COLS_OF_WORD[w]) continue;
        uint64_t eq = COLS_OF_WORD[w];
        for (int r = 0; r < 6 && eq; r++) eq &= (w >> r & 1) ? out[r] : ~out[r];
        ok |= eq;
    }
    if (CLEAN_W >= 0) ok &= ~v[CLEAN_W];
    return 64 - __builtin_popcountll(ok);
}

/* env OUT_OFFSETS="a0,a1,...": estimate = max(plain depth, max over outputs r of ready(r) + a_r).  The offsets say how
 * late the middle may receive each output (fitted on real half-word builds, 2026-09-22).
 * env OUT_FREE=1: ready(r) is the LAST TOUCH of the output's wire (last write or last read as a control), since the
 * middle can only take a wire once the code stops reading it too (2026-09-23); default: last write. */
static int USE_OFF = 0, OUT_OFF[8], OUT_FREE = 0;
static int estimate(const State *s) {
    int wready[NW] = {0}, rdone[NW] = {0}, depth = 0;
    for (int k = 0; k < s->n; k++) {
        const Gate *g = &s->g[k];
        int st = wready[g->t] > rdone[g->t] ? wready[g->t] : rdone[g->t];
        for (int j = 0; j < ncontrols(g->type); j++) if (wready[g->c[j]] > st) st = wready[g->c[j]];
        int en = st + dur(g->type);
        wready[g->t] = en;
        for (int j = 0; j < ncontrols(g->type); j++) if (rdone[g->c[j]] < en) rdone[g->c[j]] = en;
        if (en > depth) depth = en;
    }
    if (USE_OFF) {                               /* output-weighted estimate (env OUT_OFFSETS) */
        int m = 0;
        for (int r = 0; r < 6; r++) {
            int w = s->pw[r], t = wready[w];
            if (OUT_FREE && rdone[w] > t) t = rdone[w];
            int v = t + OUT_OFF[r]; if (v > m) m = v;
        }
        return m > depth ? m : depth;
    }
    return depth;
}

static int valid_gate(const Gate *g) {
    int nc = ncontrols(g->type);
    for (int j = 0; j < nc; j++) {
        if (g->c[j] == g->t) return 0;
        for (int i = 0; i < j; i++) if (g->c[i] == g->c[j]) return 0;
    }
    return 1;
}

static void random_gate(Gate *g) {
    double u = runif();
    g->type = u < 0.30 ? 1 : u < 0.80 ? 2 : u < 0.97 ? 3 : 0;
    do {
        g->t = rint_(NW);
        for (int j = 0; j < 3; j++) { g->c[j] = rint_(NW); g->p[j] = rint_(2); }
    } while (!valid_gate(g));
}

static void mutate(State *s) {
    int kind = rint_(100);
    if (s->n == 0) kind = 50;
    if (kind < 30) {                              /* change one control */
        Gate *g = &s->g[rint_(s->n)];
        int nc = ncontrols(g->type);
        if (nc == 0) { g->t = rint_(NW); return; }
        int j = rint_(nc);
        Gate h = *g;
        for (int tries = 0; tries < 20; tries++) {
            h.c[j] = rint_(NW); h.p[j] = rint_(2);
            if (valid_gate(&h)) { *g = h; return; }
        }
    } else if (kind < 38) {                       /* flip a control polarity */
        Gate *g = &s->g[rint_(s->n)];
        int nc = ncontrols(g->type);
        if (nc) g->p[rint_(nc)] ^= 1;
    } else if (kind < 46) {                       /* change target */
        Gate *g = &s->g[rint_(s->n)];
        Gate h = *g;
        for (int tries = 0; tries < 20; tries++) { h.t = rint_(NW); if (valid_gate(&h)) { *g = h; return; } }
    } else if (kind < 54) {                       /* change type */
        Gate *g = &s->g[rint_(s->n)];
        Gate h = *g;
        int d = rint_(2) ? 1 : -1;
        h.type = g->type + d;
        if (h.type < 0 || h.type > 3) return;
        for (int tries = 0; tries < 20; tries++) {
            if (h.type > g->type) { h.c[h.type - 1] = rint_(NW); h.p[h.type - 1] = rint_(2); }
            if (valid_gate(&h)) { *g = h; return; }
        }
    } else if (kind < 62) {                       /* delete */
        if (s->n <= 1) return;
        int k = rint_(s->n);
        memmove(&s->g[k], &s->g[k + 1], (s->n - k - 1) * sizeof(Gate)); s->n--;
    } else if (kind < 72) {                       /* insert */
        if (s->n >= NMAX) return;
        int k = rint_(s->n + 1);
        memmove(&s->g[k + 1], &s->g[k], (s->n - k) * sizeof(Gate)); s->n++;
        random_gate(&s->g[k]);
    } else if (kind < 82) {                       /* swap adjacent */
        if (s->n < 2) return;
        int k = rint_(s->n - 1); Gate t = s->g[k]; s->g[k] = s->g[k + 1]; s->g[k + 1] = t;
    } else if (kind < 88) {                       /* move a gate */
        if (s->n < 2) return;
        int a = rint_(s->n), b = rint_(s->n);
        Gate t = s->g[a];
        if (a < b) memmove(&s->g[a], &s->g[a + 1], (b - a) * sizeof(Gate));
        else if (a > b) memmove(&s->g[b + 1], &s->g[b], (a - b) * sizeof(Gate));
        s->g[b] = t;
    } else if (kind < 94) {                       /* placement: move a role to another wire */
        int r = rint_(6), w = rint_(NW);
        for (int q = 0; q < 6; q++) if (q != r && s->pw[q] == w) { s->pw[q] = s->pw[r]; break; }
        s->pw[r] = w;
    } else {                                      /* placement polarity */
        s->pp[rint_(6)] ^= 1;
    }
}

static double energy(const State *s, int cap, int *wrong, int *est) {
    *wrong = wrong_columns(s); *est = estimate(s);
    double over = *est > cap ? *est - cap : 0;
    return WV * *wrong + WC * over + 0.01 * *est + 0.001 * s->n;
}

static void print_state(const State *s, int est, long iter) {
    printf("SOL est=%d gates=%d wrong=0 iter=%ld\nPLACE", est, s->n, iter);
    for (int r = 0; r < 6; r++) printf(" %d %d", s->pw[r], s->pp[r]);
    printf("\nGATES %d\n", s->n);
    for (int k = 0; k < s->n; k++) {
        const Gate *g = &s->g[k];
        printf("%d %d %d %d %d %d %d %d\n", g->type, g->t, g->c[0], g->p[0], g->c[1], g->p[1], g->c[2], g->p[2]);
    }
    printf("END\n");
    fflush(stdout);
}

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: colsa TABLE INIT|- SEED ITERS CAP0 [WV WC T0 T1 NMAX RESTARTS]\n"); return 1; }
    FILE *f = fopen(argv[1], "r");
    for (int x = 0; x < 64; x++) { unsigned long long m; if (fscanf(f, "%llx", &m) != 1) return 2; ALLOWED[x] = m; }
    fclose(f);
    for (int w = 0; w < 64; w++) { COLS_OF_WORD[w] = 0; for (int x = 0; x < 64; x++) if (ALLOWED[x] >> w & 1) COLS_OF_WORD[w] |= 1ULL << x; }
    for (int i = 0; i < 6; i++) { XINIT[i] = 0; for (int x = 0; x < 64; x++) if (x >> i & 1) XINIT[i] |= 1ULL << x; }
    uint64_t seed = strtoull(argv[3], 0, 10);
    rng_s[0] = seed * 0x9E3779B97F4A7C15ULL + 1; rng_s[1] = seed ^ 0xD1B54A32D192ED03ULL; for (int i = 0; i < 20; i++) rnd();
    long iters = atol(argv[4]);
    int cap = atoi(argv[5]);
    if (argc > 6) WV = atof(argv[6]);
    if (argc > 7) WC = atof(argv[7]);
    if (argc > 8) TT0 = atof(argv[8]);
    if (argc > 9) TT1 = atof(argv[9]);
    if (argc > 10) NMAX = atoi(argv[10]);
    int restarts = argc > 11 ? atoi(argv[11]) : 1;
    if (getenv("POOL_SLACK")) POOL_SLACK = atoi(getenv("POOL_SLACK"));
    if (getenv("POOL_NSLACK")) POOL_NSLACK = atoi(getenv("POOL_NSLACK"));
    if (getenv("POOL_MAX")) POOL_MAX = atoi(getenv("POOL_MAX"));
    if (getenv("POOL_GAP")) POOL_GAP = atol(getenv("POOL_GAP"));
    if (getenv("POOL_ABSMAX")) POOL_ABSMAX = atoi(getenv("POOL_ABSMAX"));
    HSET = calloc(HSIZE, sizeof(uint64_t));
    if (getenv("OUT_OFFSETS")) {
        char buf[256]; strncpy(buf, getenv("OUT_OFFSETS"), 255); buf[255] = 0; int r = 0;
        for (char *tok = strtok(buf, ","); tok && r < 8; tok = strtok(0, ",")) OUT_OFF[r++] = atoi(tok);
        USE_OFF = 1; fprintf(stderr, "output offsets:"); for (int q = 0; q < r; q++) fprintf(stderr, " %d", OUT_OFF[q]); fprintf(stderr, "\n");
    }
    if (getenv("OUT_FREE") && atoi(getenv("OUT_FREE"))) { OUT_FREE = 1; fprintf(stderr, "output time = last touch\n"); }
    if (getenv("CLEAN_WIRE")) { CLEAN_W = atoi(getenv("CLEAN_WIRE")); fprintf(stderr, "clean wire %d\n", CLEAN_W); }
    int bestest = 1 << 30, bestn = 1 << 30, npool = 0; long lastpool = -(1L << 60);

    State init; memset(&init, 0, sizeof init);
    int have_init = strcmp(argv[2], "-") != 0;
    if (have_init) {
        FILE *g = fopen(argv[2], "r"); char word[16];
        if (fscanf(g, "%15s", word) != 1) return 3;
        for (int r = 0; r < 6; r++) if (fscanf(g, "%d %d", &init.pw[r], &init.pp[r]) != 2) return 3;
        int n; if (fscanf(g, "%15s %d", word, &n) != 2) return 3;
        init.n = n;
        for (int k = 0; k < n; k++) { Gate *q = &init.g[k]; if (fscanf(g, "%d %d %d %d %d %d %d %d", &q->type, &q->t, &q->c[0], &q->p[0], &q->c[1], &q->p[1], &q->c[2], &q->p[2]) != 8) return 3; }
        fclose(g);
    }
    int bestcap = cap;
    for (int rs = 0; rs < restarts; rs++) {
        State s;
        if (have_init) s = init;
        else {
            memset(&s, 0, sizeof s);
            int ws[NW]; for (int i = 0; i < NW; i++) ws[i] = i;
            for (int i = NW - 1; i > 0; i--) { int j = rint_(i + 1), t = ws[i]; ws[i] = ws[j]; ws[j] = t; }
            for (int r = 0; r < 6; r++) { s.pw[r] = ws[r]; s.pp[r] = rint_(2); }
            s.n = 12 + rint_(12);
            for (int k = 0; k < s.n; k++) random_gate(&s.g[k]);
        }
        int curcap = bestcap;
        int wrong, est;
        double e = energy(&s, curcap, &wrong, &est);
        int bestwrong = wrong;
        fprintf(stderr, "restart %d start: wrong %d est %d gates %d cap %d\n", rs, wrong, est, s.n, curcap);
        for (long it = 0; it < iters; it++) {
            double T = TT0 * pow(TT1 / TT0, (double)it / iters);
            State t = s;
            int nm = 1 + (runif() < 0.3 ? rint_(3) : 0);
            for (int m = 0; m < nm; m++) mutate(&t);
            int w2, e2s;
            double e2 = energy(&t, curcap, &w2, &e2s);
            if (e2 <= e || runif() < exp((e - e2) / T)) {
                s = t; e = e2; wrong = w2; est = e2s;
                if (wrong < bestwrong) { bestwrong = wrong; fprintf(stderr, "restart %d iter %ld wrong %d est %d n %d T %.3f\n", rs, it, wrong, est, s.n, T); }
                if (wrong == 0 && est <= curcap) {
                    seen_before(state_hash(&s));
                    print_state(&s, est, it);
                    if (est < bestest || (est == bestest && s.n < bestn)) { bestest = est; bestn = s.n; }
                    curcap = est - 1; if (curcap < bestcap) bestcap = curcap;
                    e = energy(&s, curcap, &wrong, &est); lastpool = it;
                } else if (wrong == 0 && POOL_SLACK >= 0 && npool < POOL_MAX && est <= bestest + POOL_SLACK && est <= POOL_ABSMAX
                           && s.n <= bestn + POOL_NSLACK && it - lastpool >= POOL_GAP && !seen_before(state_hash(&s))) {
                    print_state(&s, est, it); npool++; lastpool = it;
                }
            }
        }
        fprintf(stderr, "restart %d done: bestwrong %d cap %d\n", rs, bestwrong, curcap);
    }
    return 0;
}
