# A depth-95 phase oracle for the Classiq logo

*PoJen Wang · pwang529@gmail.com*

Our entry to the Classiq phase-oracle depth challenge (unitaryHACK 2026) is a circuit of **depth 95 with 272 `cx`**,
on 18 qubits with the `u3` + `cx` gate set. The organisers' baseline has depth 5329 with 3502 `cx`. This folder
explains how we built it.

| file | what it is |
|---|---|
| `logo-oracle-depth-95-explainer.pdf` | the written explainer (about 18 pages, blog style) |
| `classiq-challenge-depth-95-explainer.ipynb` | the companion notebook, already executed; re-run it to see every plot recomputed |
| `depth95_helpers.py` | the notebook's one helper module (logo, QASM reader, depth count, figure check, memory guard) |
| `data/` | everything the notebook reads: the final circuit, the circuits on the way down, the codes and contracts, a pairing run, the annealer's C source and its logs (`data/MANIFEST.txt` lists every file with its sha256) |

The final circuit is `data/oracle-depth-95-cx-272-6cdddada.qasm`.

## Running the notebook

```
cd depth95-explainer
pip install numpy matplotlib jupyter      # Python 3.9 or newer
jupyter notebook classiq-challenge-depth-95-explainer.ipynb
```

Run all cells; it takes under a minute and needs no Classiq account and no network. A C compiler (`gcc` or `cc`)
is optional. With one, section 7 compiles the annealer and runs a 20-million-step search live. Without one, that
section plots a stored run of the same search instead.

## Tools we used

The construction itself used: pytket (tket) and the Qiskit transpiler, to compile code circuits to `u3` + `cx`;
OR-Tools CP-SAT, for exact rescheduling; PySAT with the CaDiCaL and Kissat SAT solvers, for re-synthesising the
phase block; ShinkaEvolve, an LLM-driven program-evolution framework, to iterate on the first whole-logo sandwich (260 → 194
layers) with a full-circuit evaluator; and our own simulated
annealer (`data/colsa.c`). The report cites each of them.
